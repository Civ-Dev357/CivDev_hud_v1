/* script.js — CivDev_hud_v1
   HUD UI logic (meters, speedometer, fuel support, NUI hookup)
   Drop into: CivDev_hud_v1/html/script.js
*/

(function(){

/* ========= small utilities ========= */
function uid(prefix='id'){ return prefix + '-' + Math.random().toString(36).slice(2,9); }
function clamp(v, a, b){ return Math.max(a, Math.min(b, v)); }

/* ========= build a ring meter ========= */
function makeRingMeter(root, opts){
  const cssSize = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--meter-size')) || 64;
  const stroke = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ring-stroke')) || 6;
  const size = cssSize;
  const r = (size/2) - stroke - 4;
  const cx = size/2, cy = size/2;
  const C = 2 * Math.PI * r;
  const gradId = uid('grad');

  root.innerHTML = `
    <svg viewBox="0 0 ${size} ${size}" class="disc-glow" role="img" aria-label="${opts.label || opts.id}">
      <defs>
        <linearGradient id="${gradId}" x1="0" x2="1">
          <stop offset="0%"   stop-color="${opts.c1}"/>
          <stop offset="100%" stop-color="${opts.c2}"/>
        </linearGradient>
      </defs>
      <circle class="disc" cx="${cx}" cy="${cy}" r="${Math.max(0, r-8)}" />
      <circle class="disc-ring" cx="${cx}" cy="${cy}" r="${r}" />
      <circle id="ring-${opts.id}" cx="${cx}" cy="${cy}" r="${r}"
              fill="none" stroke="url(#${gradId})"
              stroke-width="${stroke}" stroke-linecap="round"
              style="transform:rotate(-90deg);transform-origin:${cx}px ${cy}px;
                     stroke-dasharray:${C}; stroke-dashoffset:${C}; transition:stroke-dashoffset .22s ease" />
    </svg>
    <div class="icon">${opts.icon}</div>
    <div class="label"><span class="val" id="val-${opts.id}">0</span>%</div>
  `;

  const ring = root.querySelector(`#ring-${opts.id}`);
  const valEl = root.querySelector(`#val-${opts.id}`);

  return {
    set(v){
      v = clamp(Number(v)||0, 0, 100);
      ring.style.strokeDashoffset = C - (C * v / 100);
      valEl.textContent = Math.round(v);
    }
  };
}

/* ===== icons (inline svgs) ===== */
const ICONS = {
  heart:  `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 21s-7.5-4.9-9.3-7.1C-0.5 9.6 3 5 6.8 5 9 5 12 7 12 7s3-2 5.2-2C21 5 24.5 9.6 21.3 13.9 19.5 16.1 12 21 12 21z"/></svg>`,
  shield:`<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l7 3v5c0 5-3.6 9.7-7 12-3.4-2.3-7-7-7-12V5l7-3z"/></svg>`,
  food:  `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16 4c0 .9-.6 1.6-1.3 2C13.8 7 12.9 7 12 7s-1.8 0-2.7-.1C8.6 5.6 8 4.9 8 4c0-1 0-2 2-2s3 1 4 1 2-.3 2 1zM12 9c4 0 6 3 6 6 0 3-2 5-6 5s-6-2-6-5c0-3 2-6 6-6z"/></svg>`,
  drop:  `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2S7 8 7 12a5 5 0 0 0 10 0c0-4-5-10-5-10z"/></svg>`,
  bolt:  `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z"/></svg>`,
  pump:  `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19 7h-1V3H8v4H7a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2zm-8-2h6v2h-6V5zm8 11h-1v-4h1l.001 4zM9 12h2v5H9v-5z"/></svg>`
};

/* ===== build meters ===== */
const Meter = {
  health : makeRingMeter(document.getElementById('m-health'),  { id:'health',  c1:'#fe4a63', c2:'#ff9a75', icon:ICONS.heart,  label:'Health' }),
  armor  : makeRingMeter(document.getElementById('m-armor'),   { id:'armor',   c1:'#64b6ff', c2:'#2f8bff', icon:ICONS.shield,  label:'Armor' }),
  hunger : makeRingMeter(document.getElementById('m-hunger'),  { id:'hunger',  c1:'#ffc861', c2:'#ff9650', icon:ICONS.food,   label:'Hunger' }),
  thirst : makeRingMeter(document.getElementById('m-thirst'),  { id:'thirst',  c1:'#7ef0c8', c2:'#3fe0a6', icon:ICONS.drop,   label:'Thirst' }),
  fuel   : makeRingMeter(document.getElementById('m-fuel'),    { id:'fuel',    c1:'#ffdd57', c2:'#ff8c42', icon:ICONS.pump,   label:'Fuel' }),
  stamina: makeRingMeter(document.getElementById('m-stamina'), { id:'stamina', c1:'#9d7bff', c2:'#5b76ff', icon:ICONS.bolt,   label:'Stamina' })
};

/* ===== Speedometer ===== */
const SPD = (() => {
  const host = document.getElementById('speedometer');
  const cfg  = { maxSpeed:260, startDeg:-120, endDeg:120, radius:95, stroke:10, unit:'KM/H' };

  // internal geometry width (svg scales to container)
  const w = 300;
  const cx = w/2, cy = 270;
  const deg2rad = d => (d-90)*Math.PI/180;
  const pc = (r,d)=>({x:cx+r*Math.cos(deg2rad(d)),y:cy+r*Math.sin(deg2rad(d))});
  const arc = (r,a0,a1)=>{const s=pc(r,a0),e=pc(r,a1),large=(a1-a0)<=180?0:1; return`M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`};

  host.innerHTML=`
  <svg viewBox="0 0 ${w} 300" aria-hidden="true">
    <defs>
      <linearGradient id="spd-grad-${uid('g')}" x1="0" x2="1">
        <stop offset="0%" stop-color="#06CE6B"/>
        <stop offset="75%" stop-color="#FB8607"/>
        <stop offset="100%" stop-color="#FE2436"/>
      </linearGradient>
    </defs>
    <path d="${arc(cfg.radius,cfg.startDeg,cfg.endDeg)}" stroke="#222" stroke-width="${cfg.stroke}" fill="none" stroke-linecap="round"/>
    <path id="spd-fill" d="${arc(cfg.radius,cfg.startDeg,cfg.endDeg)}" stroke="url(#spd-grad-${uid('g2')})" stroke-width="${cfg.stroke}" fill="none" stroke-linecap="round"/>
    <g id="ticks"></g>
    <g text-anchor="middle">
      <text id="spd-gear" x="${cx}" y="${cy-cfg.radius-16}" font-size="16" fill="#9aa0a6"></text>
      <text id="spd-value" x="${cx}" y="${cy-6}" font-size="40" fill="#fff" font-weight="800">0</text>
      <text id="spd-unit"  x="${cx}" y="${cy+16}" font-size="16" fill="#9aa0a6">${cfg.unit}</text>
    </g>
  </svg>
  <div class="spd-rpm-wrap" aria-hidden="true"><div class="spd-rpm-fill" id="spd-rpm"></div></div>`;

  // ticks
  const tg = host.querySelector('#ticks');
  const majors=9, subticks=3, span=cfg.endDeg-cfg.startDeg, step=span/(majors-1);
  const pc2=(r,deg)=>pc(r,deg);
  for(let i=0;i<majors;i++){
    const deg=cfg.startDeg+i*step, p1=pc2(cfg.radius-8,deg), p2=pc2(cfg.radius+12,deg);
    tg.insertAdjacentHTML('beforeend',`<line x1="${p1.x}" y1="${p1.y}" x2="${p2.x}" y2="${p2.y}" stroke="#ccc" stroke-width="2" opacity=".9"/>`);
    if(i<majors-1){
      const sstep = step/(subticks+1);
      for(let s=1;s<=subticks;s++){
        const d=deg+s*sstep, q1=pc2(cfg.radius+4,d), q2=pc2(cfg.radius+8,d);
        tg.insertAdjacentHTML('beforeend',`<line x1="${q1.x}" y1="${q1.y}" x2="${q2.x}" y2="${q2.y}" stroke="#777" stroke-width="1"/>`);
      }
    }
  }

  const path = host.querySelector('#spd-fill');
  const total = path.getTotalLength();
  path.style.strokeDasharray = `${total} ${total}`;

  const spdEl = host.querySelector('#spd-value');
  const unitEl = host.querySelector('#spd-unit');
  const gearEl = host.querySelector('#spd-gear');
  const rpmEl = host.querySelector('#spd-rpm');

  function setSpeed(v){ v = clamp(Math.round(Number(v)||0), 0, cfg.maxSpeed); path.style.strokeDashoffset = total - total*(v/cfg.maxSpeed); spdEl.textContent = Math.round(v); }
  function setUnit(u){ cfg.unit = u || cfg.unit; unitEl.textContent = cfg.unit; }
  function setGear(g){ gearEl.textContent = g ? String(g).toUpperCase() : ''; }
  function setRPM(p){ p = clamp(Number(p)||0, 0, 100); rpmEl.style.width = p + '%'; }
  function setMax(m){ const n = Number(m) || cfg.maxSpeed; cfg.maxSpeed = n; }

  return {
    set: ({ speed, maxSpeed, unit, gear, rpmPercent } = {}) => {
      if(maxSpeed !== undefined) setMax(maxSpeed);
      if(unit !== undefined) setUnit(unit);
      if(gear !== undefined) setGear(gear);
      if(rpmPercent !== undefined) setRPM(rpmPercent);
      if(speed !== undefined) setSpeed(speed);
    }
  };
})();

/* ===== Mic + ID controls ===== */
const micDot = document.getElementById('mic-dot');
const idEl   = document.getElementById('player-id');
function setSpeaking(on){ micDot.classList.toggle('on', !!on); }
function setServerId(id){ idEl.textContent = '#' + String(id ?? 0); }

/* ===== Responsive scaling for meters & speedo ===== */
function applyScaling(){
  const wh = window.innerHeight || 720;
  const size = clamp(Math.round(wh * 0.085), 48, 110);
  document.documentElement.style.setProperty('--meter-size', size + 'px');

  const ww = window.innerWidth || 1280;
  const spd = clamp(Math.round(Math.min(520, ww * 0.33)), 220, 540);
  document.documentElement.style.setProperty('--spd-size', spd + 'px');
}
window.addEventListener('resize', applyScaling, { passive:true });
applyScaling();

/* ===== Demo animation (preview only) ===== */
(function demoLoop(){
  let last = performance.now();
  let speed = 86, dir = 1, gear = 'D', unit = 'KM/H', speaking = false, id = 23;
  setServerId(id);
  SPD.set({ speed, rpmPercent: (speed/260)*100, gear, unit });

  let t = 0;
  let meterQueue = null;
  function updateMeters(){
    const s = t;
    Meter.health.set(80 + 18*Math.sin(s*1.2));
    Meter.armor.set(40 + 30*(0.5+0.5*Math.sin(s*0.9)));
    Meter.hunger.set(60 + 25*Math.sin(s*0.7+1.4));
    Meter.thirst.set(50 + 35*Math.sin(s*1.1+0.6));
    Meter.fuel.set(75 + 20*Math.sin(s*0.5)); // demo fuel movement
    Meter.stamina.set(55 + 45*(0.5+0.5*Math.cos(s*1.6)));
    meterQueue = null;
  }

  function frame(now){
    const dt = (now - last) / 1000;
    last = now;
    t += dt * 1.6;

    speed += dir * 40 * dt;
    if(speed > 220) { dir = -1; speed = 220; }
    if(speed < 20)  { dir = 1;  speed = 20;  }

    SPD.set({ speed, rpmPercent: (speed/260)*100 });

    if(!meterQueue) meterQueue = requestAnimationFrame(()=>updateMeters());
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  window.addEventListener('keydown', (e)=>{
    if(e.key === 'ArrowUp'){ speed = clamp(speed + 8, 0, 999); SPD.set({ speed }); }
    if(e.key === 'ArrowDown'){ speed = clamp(speed - 8, 0, 999); SPD.set({ speed }); }
    if(e.key.toLowerCase() === 'm'){ speaking = !speaking; setSpeaking(speaking); }
    if(e.key.toLowerCase() === 'g'){
      const gears=['P','R','N','D','1','2','3','4','5','6'];
      const i = Math.max(0, gears.indexOf(gear));
      gear = gears[(i+1) % gears.length];
      SPD.set({ gear });
    }
    if(e.key.toLowerCase() === 'u'){
      unit = unit === 'KM/H' ? 'MPH' : 'KM/H';
      SPD.set({ unit });
    }
  });
})();

/* ===== NUI / postMessage hookup =====
   Expects payload fields:
   health, armor, hunger, thirst, stamina, fuel (0..100), speed, rpm, currentGear, speedUnit, maxSpeed, speaking, serverId
*/
window.addEventListener('message', (ev) => {
  const d = ev.data;
  if(!d || typeof d !== 'object') return;
  if(d.action === 'update' && d.payload){
    const p = d.payload;

    if(p.health  != null) Meter.health.set(p.health);
    if(p.armor   != null) Meter.armor.set(p.armor);
    if(p.hunger  != null) Meter.hunger.set(p.hunger);
    if(p.thirst  != null) Meter.thirst.set(p.thirst);
    if(p.fuel    != null) Meter.fuel.set(p.fuel);   // <-- fuel applied here
    if(p.stamina != null) Meter.stamina.set(p.stamina);

    if(p.speed !== undefined || p.rpm !== undefined || p.currentGear !== undefined || p.speedUnit !== undefined || p.maxSpeed !== undefined){
      SPD.set({
        speed:      p.speed,
        rpmPercent: p.rpm,
        gear:       p.currentGear,
        unit:       p.speedUnit,
        maxSpeed:   p.maxSpeed
      });
    }

    if(p.serverId != null) setServerId(p.serverId);
    if(p.speaking != null) setSpeaking(p.speaking);
  }
}, false);

/* ===== debug API ===== */
window.HUD = {
  setMeters: (obj) => {
    if(obj.health != null) Meter.health.set(obj.health);
    if(obj.armor != null)  Meter.armor.set(obj.armor);
    if(obj.hunger != null) Meter.hunger.set(obj.hunger);
    if(obj.thirst != null) Meter.thirst.set(obj.thirst);
    if(obj.fuel != null)   Meter.fuel.set(obj.fuel);
    if(obj.stamina != null) Meter.stamina.set(obj.stamina);
  },
  setSpeed: (s, rpmPct, gear, unit, max) => SPD.set({ speed:s, rpmPercent:rpmPct, gear, unit, maxSpeed:max })
};

})(); // end IIFE
